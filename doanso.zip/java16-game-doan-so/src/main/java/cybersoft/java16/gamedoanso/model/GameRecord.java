package cybersoft.java16.gamedoanso.model;

public class GameRecord {

}
