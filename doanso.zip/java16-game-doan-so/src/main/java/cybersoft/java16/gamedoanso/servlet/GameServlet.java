package cybersoft.java16.gamedoanso.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "gameServlet", urlPatterns = "/game" )

public class GameServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter printWriter = resp.getWriter();
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");
		
		String random = req.getParameter("random");
		String count = req.getParameter("count");
		String idplayer = req.getParameter("idplayer");
		int countInt = Integer.parseInt(count);
		countInt++;
		//printWriter.append("-- ID Player: " + idplayer + " - Random number: " + random + " - Số lần đoán: " + countInt );
		
		resp.getWriter().append("<form action=\"/java16-game-doan-so/service\" method=\"POST\">\r\n"
				+ " <h4>Bạn đoán: </h4>\r\n"
				+ " <input type=\"text\" name=\"number\" id=\"number\">\r\n"
				+ " <input style=\"display:none\" type=\"text\" name=\"random\" value=" +random +">\r\n"
				+ " <input style=\"display:none\" type=\"text\" name=\"count\" value=" +countInt + ">\r\n"
				+ " <input type=\"text\" name=\"idplayer\" value=" +idplayer + ">\r\n"
				+ " <input type=\"submit\" name=\"submit\" id = \"submit\" value=\"Kết quả\">\r\n"
				+ " </form>"
				);
	
		
		
		
	}
		
	
	
}
