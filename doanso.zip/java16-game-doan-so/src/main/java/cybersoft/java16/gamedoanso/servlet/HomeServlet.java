package cybersoft.java16.gamedoanso.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="homeServlet", urlPatterns = "/home")
public class HomeServlet extends HttpServlet {
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Random generator = new Random();
		int randomNumber = generator.nextInt(10)+1;
		int count = 0;
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");

		resp.getWriter().append("<form action=\"\" method=\"POST\">\r\n"
				+ "        <h3>TRÒ CHƠI ĐOÁN SỐ 1-1000</h3>\r\n"
				+ "        <h4>Tên người chơi: </h4>\r\n"
				+ "        <input type=\"text\" name=\"idplayer\" id=\"idplayer\">\r\n"
				+ "        <input type=\"text\" name=\"random\" value=" +randomNumber +">\r\n"
				+ "        <input type=\"text\" name=\"count\" value=" +count + ">\r\n"
				+ "        <input type=\"submit\" name=\"submit\" value=\"Gửi\">\r\n"
				+ "    </form>");
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");
		
		String random = req.getParameter("random");
		String count = req.getParameter("count");
		String idplayer = req.getParameter("idplayer");
						
		//neu player nhap idplayer thi thong tin duoc gui ve cho server, nguoc lai thi van o trang day
		if(!idplayer.equals("")) {
			req.getRequestDispatcher("/game").forward(req, resp);
			
		}
		else {
			resp.sendRedirect(req.getContextPath()+ "/home");
		}
		
		
	}
}
