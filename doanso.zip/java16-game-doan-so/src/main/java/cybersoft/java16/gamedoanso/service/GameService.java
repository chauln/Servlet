package cybersoft.java16.gamedoanso.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javafx.print.Printer;
@WebServlet(name = "gameService", urlPatterns = "/service")
public class GameService extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");
		
		String idplayer = req.getParameter("idplayer");
		String count = req.getParameter("count");
			
		int numberGuess = Integer.parseInt(req.getParameter("number"));
		int numberRandom = Integer.parseInt(req.getParameter("random"));
		int countN = Integer.parseInt(count);
		
				
		if(numberGuess > numberRandom) {
			resp.getWriter().append("-------Số đoán lớn hơn số bí mật ------- ");
			req.getRequestDispatcher("/game").include(req, resp);
			
		}
		else if(numberGuess <numberRandom) {
			resp.getWriter().append("--------Số đoán nhỏ hơn số bí mật -------");
			req.getRequestDispatcher("/game").include(req, resp);
		}
		else {
			resp.getWriter().append("------Bạn đã đoán đúng số bí mật ----- ");
			resp.getWriter().append("Bạn đã đoán trúng sau " + countN + " lần.");
		
			req.getRequestDispatcher("/player").include(req, resp);
			
		} 
		
	}
	
}
